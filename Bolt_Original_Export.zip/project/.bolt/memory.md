# Project memory

## Product intent & audience

- Room booking/availability management app built with Vite + React.
- Users select a room and propose a booking time; the app validates availability and gives feedback.
- Governed by acceptance criteria AC1–AC6 (availability check, overlap detection, clear feedback, time validation).

## Brand personality & voice

- Production-quality, polished UI expected; avoid cookie-cutter layouts.
- User-facing feedback should be clear and unambiguous (AC6).

## Visual design & UX direction

- React + Tailwind CSS; Lucide React for icons.
- Time inputs are text-based with regex parsing (`parseTime`); live preview on keystroke.
- `@/` path alias maps to `src/`.
- No UI theme/icon packages beyond defaults.

## Decisions, constraints & rationale

- Core logic lives in `src/lib/availability.ts`: `checkAvailability`, `formatTime`, `parseTime`, overlap detection.
- UI orchestration in `src/App.tsx`; warnings are hand-written copy separate from logic messages (drift risk noted).
- Testing via Vitest (`package.json` test script); no CI workflow files present.
- No files were modified in this turn; no tests were executed. All findings were code-inspection only.

## Open questions & assumptions

- Input validation gaps: `checkAvailability` doesn't validate `now` (integer/range) or `roomId`; booking fixtures not validated for integer times or `start < end`.
- Time inputs lack `maxLength`; regex per keystroke may cause jank under pathological input (unverified).
- UI copy vs. logic message drift between `App.tsx` and `availability.ts` — no automated guard.
- R1 (input validation → AC6) and R5 (booking validation → AC4) recommended for independent test-based verification.